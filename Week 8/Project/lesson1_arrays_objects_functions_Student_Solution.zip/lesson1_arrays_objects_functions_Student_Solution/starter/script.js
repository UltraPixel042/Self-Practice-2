const quotes = []
let nextId = 1
function addQuote(content, author) {}

function deleteQuote(id) {}

function updateQuote(id, content, author) {}

function getAllQuotes() {}

// Test your functions below
// TODO: Add 3 quotes using addQuote()
// TODO: Delete 1 quote using deleteQuote()
// TODO: Update 1 quote using updateQuote()
// TODO: Print all quotes using getAllQuotes()
